# SSN CNC
You just got #SpaceyLogged! We thank you for your apis and your 200 british pounds!
```
go run bypass/licensebypass.go
iptables -t nat -A OUTPUT -p tcp -d 54.39.235.240 --dport 38372 -j DNAT --to-destination 127.0.0.1:9999
Setup the CNC like you normally would.
```